﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameMaster : MonoBehaviour {

	public static GameMaster instance = null;

    public static GeneralManager gm_generalManager;
    public static WorldManager gm_worldManager;
    public static DataManager gm_dataManager;

    public static MineshaftOverseerManager gm_MineshaftOverseerManager;
    public static ElevatorOverseerManager gm_ElevatorOverseerManager;
    public static WarehouseOverseerManager gm_WarehouseOverseerManager;

    public static MineshaftUpgradeManager gm_MineshaftUpgradeManager;
    public static ElevatorUpgradeManager gm_ElevatorUpgradeManager;
    public static WarehouseUpgradeManager gm_WarehouseUpgradeManager;

    public Warehouse gm_warehouse;
    public Elevator gm_elevator; 
    public Dictionary<int, Mineshaft> gm_mineshafts = new Dictionary<int, Mineshaft>();

    public Dictionary<int, MineshaftOverseer> gm_mineshaftOverseers = new Dictionary<int, MineshaftOverseer>();
    public Dictionary<int, WarehouseOverseer> gm_warehouseOverseers = new Dictionary<int, WarehouseOverseer>();
    public Dictionary<int, ElevatorOverseer> gm_elevatorOverseers = new Dictionary<int, ElevatorOverseer>();

    private int gm_cash = 10;
    private int gm_iceCash = 0;
    private int gm_fireCash = 0;
    private int gm_idleCash = 0;
    private int gm_superCash = 0;

	private void Awake(){
		if (instance == null) {
			instance = this;
		} else if (instance != this) {
			Destroy (gameObject);
		}
		DontDestroyOnLoad (gameObject);
	}

    private void OnEnable() 
    {
        gm_generalManager = GetComponent<GeneralManager>();
        gm_worldManager = GetComponent<WorldManager>();
        gm_dataManager = GetComponent<DataManager>();
        gm_MineshaftUpgradeManager = GetComponent<MineshaftUpgradeManager>();
        gm_MineshaftOverseerManager = GetComponent<MineshaftOverseerManager>();
        gm_ElevatorUpgradeManager = GetComponent<ElevatorUpgradeManager>();
        gm_ElevatorOverseerManager = GetComponent<ElevatorOverseerManager>();
        gm_WarehouseUpgradeManager = GetComponent<WarehouseUpgradeManager>();
        gm_WarehouseOverseerManager = GetComponent<WarehouseOverseerManager>();
    }

    private void Start()
    {
        gm_dataManager.CallEventLoadData();
        gm_generalManager.CallEventUpdateCash();
        gm_generalManager.CallEventUpdateIdleCash();
        gm_generalManager.CallEventUpdateSuperCash();
        gm_generalManager.CallEventUpdateIceCash();
        gm_generalManager.CallEventUpdateFireCash();
    }

    //Getters
    public int GetCash()
    {
        return gm_cash;
    }

    public int GetIdleCash()
    {
        return gm_idleCash;
    }

    public int GetSuperCash()
    {
        return gm_superCash;
    }

    public int GetIceCash()
    {
        return gm_iceCash;
    }

    public int GetFireCash()
    {
        return gm_fireCash;
    }

    //Setters
    public void SetCash(int updatedCash)
    {
        gm_cash = updatedCash;
    }

    public void SetIdleCash(int updatedIdleCash)
    {
        gm_idleCash = updatedIdleCash;
    }

    public void SetSuperCash(int updatedSuperCash)
    {
        gm_superCash = updatedSuperCash;
    }

    public void SetIceCash(int updatedIceCash)
    {
        gm_iceCash = updatedIceCash;
    }

    public void SetFireCash(int updatedFireCash)
    {
        gm_fireCash = updatedFireCash;
    }

    float CalculateIdleMoney(float idleCash)
    {
        return idleCash;
    }

    //public IEnumerator AutoMine(){
    //	while (bAutoMine) {
    //		if (!m_traveled) {
    //			m_travelTime -= Time.deltaTime;
    //			if (m_travelTime <= 0) {
    //				m_traveled = true;
    //				m_travelTime = m_travelTimeReset;
    //			}
    //		}
    //		if (m_traveled) {
    //			m_extractionTime -= Time.deltaTime;
    //			if (m_extractionTime <= 0) {
    //				m_extracted = true;
    //				m_extractionTime = m_extractionTimeReset;
    //			}
    //		}
    //		if (m_extracted && m_traveled) {
    //			m_travelTime -= Time.deltaTime;
    //			if (m_travelTime <= 0) {
    //				m_total += m_rate;
    //				m_extracted = false;
    //				m_traveled = false;
    //				m_travelTime = m_travelTimeReset;
    //			}
    //		}
    //		yield return null;
    //	}
    //}

    //public IEnumerator AutoTransport(){
    //	while (bAutoTransport) {
    //		if (!t_traveled) {
    //			t_travelTime -= Time.deltaTime;
    //			if (t_travelTime <= 0) {
    //				t_traveled = true;
    //				t_travelTime = t_travelTimeReset;
    //			}
    //		}
    //		if (t_traveled) {
    //			t_extractionTime -= Time.deltaTime;
    //			if (t_extractionTime <= 0 && m_total > 0) {
    //				t_extracted = true;
    //				t_extractionTime = t_extractionTimeReset;
    //			}
    //		}
    //		if (t_extracted && t_traveled) {
    //			t_travelTime -= Time.deltaTime;
    //			if (t_travelTime <= 0) {
    //				t_total += m_rate;
    //				t_extracted = false;
    //				t_traveled = false;
    //				t_travelTime = t_travelTimeReset;
    //			}
    //		}
    //		yield return null;
    //	}
    //}

    //public IEnumerator AutoCollect(){
    //	while (bAutoCollect) {
    //		if (!c_traveled) {
    //			c_travelTime -= Time.deltaTime;
    //			if (c_travelTime <= 0) {
    //				c_traveled = true;
    //				c_travelTime = c_travelTimeReset;
    //			}
    //		}
    //		if (c_traveled) {
    //			c_extractionTime -= Time.deltaTime;
    //			if (c_extractionTime <= 0) {
    //				c_extracted = true;
    //				c_extractionTime = c_extractionTimeReset;
    //			}
    //		}
    //		if (c_extracted && c_traveled) {
    //			c_travelTime -= Time.deltaTime;
    //			if (c_travelTime <= 0) {
    //				gm_cash += c_rate;
    //				c_extracted = false;
    //				c_traveled = false;
    //				c_travelTime = c_travelTimeReset;
    //			}
    //		}
    //		yield return null;
    //	}
    //}
}
